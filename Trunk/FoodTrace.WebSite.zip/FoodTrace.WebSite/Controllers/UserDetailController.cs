﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FoodTrace.WebSite.Controllers
{
    public class UserDetailController : BaseController
    {
        // GET: UserDetail
        public ActionResult Index()
        {
            return View();
        }
    }
}